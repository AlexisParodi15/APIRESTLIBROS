﻿Public Class LibroRepository
    Implements ILibroRepository

    Private ReadOnly _libros As New List(Of Libro)
    Private _siguienteId As Integer = 1

    Public Function ObtenerTodos() As List(Of Libro) Implements ILibroRepository.ObtenerTodos
        Return _libros
    End Function

    Public Function ObtenerPorId(id As Integer) As Libro Implements ILibroRepository.ObtenerPorId
        Return _libros.FirstOrDefault(Function(l) l.Id = id)
    End Function

    Public Sub Agregar(libro As Libro) Implements ILibroRepository.Agregar
        libro.Id = _siguienteId
        _siguienteId += 1
        _libros.Add(libro)
    End Sub

    Public Sub Modificar(libro As Libro) Implements ILibroRepository.Modificar
        Dim libroExistente = _libros.FirstOrDefault(Function(l) l.Id = libro.Id)
        If libroExistente IsNot Nothing Then
            libroExistente.Titulo = libro.Titulo
            libroExistente.Autor = libro.Autor
            libroExistente.AnioPublicacion = libro.AnioPublicacion
        End If
    End Sub

    Public Sub Eliminar(id As Integer) Implements ILibroRepository.Eliminar
        Dim libro = _libros.FirstOrDefault(Function(l) l.Id = id)
        If libro IsNot Nothing Then
            _libros.Remove(libro)
        End If
    End Sub
End Class
