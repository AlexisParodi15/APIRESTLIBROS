﻿Public Class Libro
    Public Property Id As Integer
    Public Property Titulo As String
    Public Property Autor As String
    Public Property AnioPublicacion As Integer
End Class
