﻿Public Class LibroService
    Implements ILibroService

    Private ReadOnly _repository As ILibroRepository

    Public Sub New(repository As ILibroRepository)
        _repository = repository
    End Sub

    Public Function ObtenerTodos() As List(Of Libro) Implements ILibroService.ObtenerTodos
        Return _repository.ObtenerTodos()
    End Function

    Public Function ObtenerPorId(id As Integer) As Libro Implements ILibroService.ObtenerPorId
        Return _repository.ObtenerPorId(id)
    End Function

    Public Sub Agregar(libro As Libro) Implements ILibroService.Agregar
        ' Aquí podrías poner reglas, ej: If String.IsNullOrEmpty(libro.Titulo) Then ...
        _repository.Agregar(libro)
    End Sub

    Public Sub Modificar(libro As Libro) Implements ILibroService.Modificar
        _repository.Modificar(libro)
    End Sub

    Public Sub Eliminar(id As Integer) Implements ILibroService.Eliminar
        _repository.Eliminar(id)
    End Sub
End Class