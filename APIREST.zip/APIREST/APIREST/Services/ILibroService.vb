﻿Public Interface ILibroService
    Function ObtenerTodos() As List(Of Libro)
    Function ObtenerPorId(id As Integer) As Libro
    Sub Agregar(libro As Libro)
    Sub Modificar(libro As Libro)
    Sub Eliminar(id As Integer)
End Interface
