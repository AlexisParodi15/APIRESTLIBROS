﻿Imports Microsoft.AspNetCore.Builder
Imports Microsoft.Extensions.DependencyInjection
Imports Microsoft.Extensions.Hosting

Module Program
    Sub Main(args As String())
        Dim builder = WebApplication.CreateBuilder(args)


        builder.Services.AddControllers()


        builder.Services.AddSingleton(Of ILibroRepository, LibroRepository)()


        builder.Services.AddScoped(Of ILibroService, LibroService)()


        Dim app = builder.Build()

        app.UseAuthorization()
        app.MapControllers()


        app.Run()
    End Sub
End Module
