﻿Imports System.Runtime.InteropServices
Imports Microsoft.AspNetCore.Mvc

<Route("api/[controller]")>
<ApiController>
Public Class LibrosController
    Inherits ControllerBase

    Private ReadOnly _service As ILibroService

    Public Sub New(service As ILibroService)
        _service = service
    End Sub

    <HttpGet>
    Public Function GetLibros() As IActionResult
        Dim libros = _service.ObtenerTodos()
        Return Ok(libros)
    End Function

    <HttpGet("{id}")>
    Public Function GetLibro(id As Integer) As IActionResult
        Dim libro = _service.ObtenerPorId(id)
        If libro Is Nothing Then Return NotFound()
        Return Ok(libro)
    End Function

    <HttpPost>
    Public Function PostLibro(<FromBody> libro As Libro) As IActionResult
        _service.Agregar(libro)
        Return CreatedAtAction(NameOf(GetLibro), New With {.id = libro.Id}, libro)
    End Function

    <HttpPut("{id}")>
    Public Function PutLibro(id As Integer, <FromBody> libro As Libro) As IActionResult
        If id <> libro.Id Then Return BadRequest()

        Dim libroExistente = _service.ObtenerPorId(id)
        If libroExistente Is Nothing Then Return NotFound()

        _service.Modificar(libro)
        Return NoContent()
    End Function

    <HttpDelete("{id}")>
    Public Function DeleteLibro(id As Integer) As IActionResult
        Dim libroExistente = _service.ObtenerPorId(id)
        If libroExistente Is Nothing Then Return NotFound()

        _service.Eliminar(id)
        Return NoContent()
    End Function
End Class
